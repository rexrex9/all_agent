import os

# 设置工作目录
dir_path = '/home/user'
os.chdir(dir_path)

# 执行列宽调整脚本
os.system('python3 adjust_column_widths.py')