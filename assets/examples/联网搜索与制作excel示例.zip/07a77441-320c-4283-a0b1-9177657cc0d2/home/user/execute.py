import os
import subprocess

# 设置工作目录
dir_path = '/home/user'
os.chdir(dir_path)

# 执行列宽调整脚本
result = subprocess.run(['python3', 'adjust_column_widths.py'], capture_output=True, text=True)

# 输出结果
print('脚本执行结果:')
print(result.stdout)
if result.stderr:
    print('错误信息:')
    print(result.stderr)