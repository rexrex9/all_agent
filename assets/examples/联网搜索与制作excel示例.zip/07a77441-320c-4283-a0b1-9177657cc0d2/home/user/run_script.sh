#!/bin/bash
chmod +x /home/user/adjust_column_widths.py
cd /home/user
python3 adjust_column_widths.py