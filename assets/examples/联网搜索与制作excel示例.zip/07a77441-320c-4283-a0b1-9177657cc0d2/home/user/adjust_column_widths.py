import openpyxl

# 打开工作簿
wb = openpyxl.load_workbook('D:/agent_files/07a77441-320c-4283-a0b1-9177657cc0d2/home/user/2025_gpu_performance.xlsx')
sheet = wb['2025显卡性能参数']

# 设置列宽
column_widths = {
    'A': 20,  # 显卡型号
    'B': 15,  # 架构
    'C': 22,  # CUDA核心/流处理器数量
    'D': 12,  # 显存容量
    'E': 10,  # 显存类型
    'F': 12,  # 显存位宽
    'G': 12,  # 基础频率
    'H': 12,  # Boost频率
    'I': 10,  # TDP功耗
    'J': 15,  # 3DMark Time Spy分数
    'K': 15,  # 推荐价格（人民币）
    'L': 12   # 发布日期
}

for col, width in column_widths.items():
    sheet.column_dimensions[col].width = width

# 保存工作簿
wb.save('D:/agent_files/07a77441-320c-4283-a0b1-9177657cc0d2/home/user/2025_gpu_performance.xlsx')
print('列宽调整完成')