#!/bin/bash
python3 /home/user/adjust_column_widths.py