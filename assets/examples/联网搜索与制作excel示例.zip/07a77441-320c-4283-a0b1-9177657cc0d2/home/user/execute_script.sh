#!/bin/bash
chmod +x /home/user/run_adjust_widths.sh
cd /home/user
python3 adjust_column_widths.py