// 导航栏切换
const navToggle = document.getElementById('nav-toggle');
const navMenu = document.querySelector('.nav-menu');

navToggle.addEventListener('click', () => {
    navMenu.classList.toggle('active');
});

// 平滑滚动
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        
        const targetId = this.getAttribute('href');
        const targetElement = document.querySelector(targetId);
        
        if (targetElement) {
            window.scrollTo({
                top: targetElement.offsetTop - 100,
                behavior: 'smooth'
            });
        }
        
        // 关闭移动菜单
        if (navMenu.classList.contains('active')) {
            navMenu.classList.remove('active');
        }
    });
});

// 滚动时导航栏效果
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.style.background = 'rgba(255, 255, 255, 0.1)';
        navbar.style.boxShadow = '0 10px 30px rgba(0, 0, 0, 0.2)';
    } else {
        navbar.style.background = 'rgba(255, 255, 255, 0.05)';
        navbar.style.boxShadow = 'none';
    }
});

// 交互式实验 - 注意力权重可视化
const attentionInput = document.getElementById('attention-input');
const analyzeAttentionBtn = document.getElementById('analyze-attention');
const attentionVisualization = document.getElementById('attention-visualization');

analyzeAttentionBtn.addEventListener('click', () => {
    const text = attentionInput.value.trim();
    if (!text) return;
    
    // 模拟注意力权重计算
    const words = text.split(' ');
    
    // 创建注意力热力图
    attentionVisualization.innerHTML = '';
    const heatmap = document.createElement('div');
    heatmap.style.display = 'grid';
    heatmap.style.gridTemplateColumns = `repeat(${words.length}, 1fr)`;
    heatmap.style.gap = '2px';
    heatmap.style.marginTop = '1rem';
    heatmap.style.padding = '1rem';
    heatmap.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
    heatmap.style.borderRadius = '12px';
    
    // 为每个单词创建一个单元格
    for (let i = 0; i < words.length; i++) {
        for (let j = 0; j < words.length; j++) {
            const cell = document.createElement('div');
            cell.style.padding = '0.5rem';
            cell.style.textAlign = 'center';
            cell.style.fontSize = '0.8rem';
            cell.style.color = '#e0e0e0';
            cell.style.borderRadius = '6px';
            
            // 生成随机注意力权重（模拟）
            const attentionWeight = 0.3 + Math.random() * 0.7;
            
            // 根据权重设置颜色（从蓝色到红色）
            const r = Math.floor(255 * attentionWeight);
            const g = Math.floor(255 * (1 - attentionWeight));
            const b = Math.floor(100 + 155 * attentionWeight);
            
            cell.style.backgroundColor = `rgb(${r}, ${g}, ${b})`;
            cell.style.opacity = attentionWeight;
            
            // 如果是同一位置，显示单词
            if (i === j) {
                cell.textContent = words[i];
            }
            
            heatmap.appendChild(cell);
        }
    }
    
    attentionVisualization.appendChild(heatmap);
});

// 词嵌入空间可视化
const word1Input = document.getElementById('word1');
const word2Input = document.getElementById('word2');
const word3Input = document.getElementById('word3');
const plotEmbeddingBtn = document.getElementById('plot-embedding');
const embeddingVisualization = document.getElementById('embedding-visualization');

plotEmbeddingBtn.addEventListener('click', () => {
    const word1 = word1Input.value.trim();
    const word2 = word2Input.value.trim();
    const word3 = word3Input.value.trim();
    
    if (!word1 || !word2 || !word3) return;
    
    // 模拟词向量计算
    embeddingVisualization.innerHTML = '';
    
    // 创建画布
    const canvas = document.createElement('canvas');
    canvas.width = 500;
    canvas.height = 500;
    canvas.style.borderRadius = '12px';
    canvas.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
    
    const ctx = canvas.getContext('2d');
    
    // 绘制坐标轴
    ctx.strokeStyle = '#4ade80';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(250, 50);
    ctx.lineTo(250, 450);
    ctx.moveTo(50, 250);
    ctx.lineTo(450, 250);
    ctx.stroke();
    
    // 绘制网格
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.lineWidth = 1;
    for (let i = 50; i <= 450; i += 50) {
        ctx.beginPath();
        ctx.moveTo(i, 50);
        ctx.lineTo(i, 450);
        ctx.moveTo(50, i);
        ctx.lineTo(450, i);
        ctx.stroke();
    }
    
    // 为每个词生成随机位置（模拟词向量）
    const positions = {
        [word1]: {x: 150 + Math.random() * 200, y: 150 + Math.random() * 200},
        [word2]: {x: 150 + Math.random() * 200, y: 150 + Math.random() * 200},
        [word3]: {x: 150 + Math.random() * 200, y: 150 + Math.random() * 200}
    };
    
    // 计算向量关系
    const vector1 = {x: positions[word2].x - positions[word1].x, y: positions[word2].y - positions[word1].y};
    const target = {x: positions[word3].x + vector1.x, y: positions[word3].y + vector1.y};
    
    // 绘制词向量
    const colors = ['#4ade80', '#3b82f6', '#f59e0b'];
    const wordsArray = [word1, word2, word3];
    
    wordsArray.forEach((word, index) => {
        const pos = positions[word];
        
        // 绘制点
        ctx.fillStyle = colors[index];
        ctx.beginPath();
        ctx.arc(pos.x, pos.y, 8, 0, Math.PI * 2);
        ctx.fill();
        
        // 绘制标签
        ctx.fillStyle = '#e0e0e0';
        ctx.font = '14px Inter';
        ctx.textAlign = 'center';
        ctx.fillText(word, pos.x, pos.y - 15);
    });
    
    // 绘制向量箭头
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(positions[word1].x, positions[word1].y);
    ctx.lineTo(positions[word2].x, positions[word2].y);
    ctx.stroke();
    
    // 绘制箭头
    ctx.beginPath();
    ctx.moveTo(positions[word3].x, positions[word3].y);
    ctx.lineTo(target.x, target.y);
    ctx.stroke();
    
    // 绘制箭头头部
    const arrowSize = 10;
    const angle = Math.atan2(target.y - positions[word3].y, target.x - positions[word3].x);
    
    ctx.beginPath();
    ctx.moveTo(target.x, target.y);
    ctx.lineTo(target.x - arrowSize * Math.cos(angle - Math.PI/6), target.y - arrowSize * Math.sin(angle - Math.PI/6));
    ctx.lineTo(target.x - arrowSize * Math.cos(angle + Math.PI/6), target.y - arrowSize * Math.sin(angle + Math.PI/6));
    ctx.closePath();
    ctx.fillStyle = '#f59e0b';
    ctx.fill();
    
    embeddingVisualization.appendChild(canvas);
});

// 模拟可视化
const rnnVisualization = document.getElementById('rnn-visualization');
const transformerVisualization = document.getElementById('transformer-visualization');
const llmVisualization = document.getElementById('llm-visualization');

// 为RNN创建简单的可视化
setTimeout(() => {
    const rnnCanvas = document.createElement('canvas');
    rnnCanvas.width = 400;
    rnnCanvas.height = 200;
    rnnCanvas.style.borderRadius = '12px';
    rnnCanvas.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
    
    const rnnCtx = rnnCanvas.getContext('2d');
    
    // 绘制RNN单元
    rnnCtx.fillStyle = '#4ade80';
    rnnCtx.fillRect(150, 50, 100, 100);
    rnnCtx.fillStyle = '#e0e0e0';
    rnnCtx.font = '14px Inter';
    rnnCtx.textAlign = 'center';
    rnnCtx.fillText('RNN单元', 200, 100);
    
    // 绘制输入
    rnnCtx.fillStyle = '#3b82f6';
    rnnCtx.fillRect(50, 80, 30, 40);
    rnnCtx.fillStyle = '#e0e0e0';
    rnnCtx.fillText('输入', 65, 100);
    
    // 绘制输出
    rnnCtx.fillStyle = '#f59e0b';
    rnnCtx.fillRect(320, 80, 30, 40);
    rnnCtx.fillStyle = '#e0e0e0';
    rnnCtx.fillText('输出', 335, 100);
    
    // 绘制循环连接
    rnnCtx.strokeStyle = '#4ade80';
    rnnCtx.lineWidth = 2;
    rnnCtx.beginPath();
    rnnCtx.moveTo(250, 100);
    rnnCtx.lineTo(350, 100);
    rnnCtx.lineTo(350, 150);
    rnnCtx.lineTo(150, 150);
    rnnCtx.lineTo(150, 100);
    rnnCtx.stroke();
    
    // 绘制箭头
    rnnCtx.beginPath();
    rnnCtx.moveTo(350, 100);
    rnnCtx.lineTo(340, 95);
    rnnCtx.lineTo(340, 105);
    rnnCtx.closePath();
    rnnCtx.fill();
    
    rnnVisualization.appendChild(rnnCanvas);
}, 100);

// 为Transformer创建简单的可视化
setTimeout(() => {
    const transformerCanvas = document.createElement('canvas');
    transformerCanvas.width = 500;
    transformerCanvas.height = 300;
    transformerCanvas.style.borderRadius = '12px';
    transformerCanvas.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
    
    const transformerCtx = transformerCanvas.getContext('2d');
    
    // 绘制编码器
    transformerCtx.fillStyle = '#4ade80';
    transformerCtx.fillRect(50, 50, 100, 200);
    transformerCtx.fillStyle = '#e0e0e0';
    transformerCtx.font = '14px Inter';
    transformerCtx.textAlign = 'center';
    transformerCtx.fillText('编码器', 100, 150);
    
    // 绘制解码器
    transformerCtx.fillStyle = '#3b82f6';
    transformerCtx.fillRect(350, 50, 100, 200);
    transformerCtx.fillStyle = '#e0e0e0';
    transformerCtx.fillText('解码器', 400, 150);
    
    // 绘制注意力连接
    transformerCtx.strokeStyle = '#f59e0b';
    transformerCtx.lineWidth = 2;
    transformerCtx.setLineDash([5, 5]);
    transformerCtx.beginPath();
    transformerCtx.moveTo(150, 100);
    transformerCtx.lineTo(350, 100);
    transformerCtx.stroke();
    
    transformerCtx.beginPath();
    transformerCtx.moveTo(150, 150);
    transformerCtx.lineTo(350, 150);
    transformerCtx.stroke();
    
    transformerCtx.beginPath();
    transformerCtx.moveTo(150, 200);
    transformerCtx.lineTo(350, 200);
    transformerCtx.stroke();
    
    // 绘制输入序列
    transformerCtx.fillStyle = '#e0e0e0';
    transformerCtx.font = '12px Inter';
    transformerCtx.textAlign = 'center';
    for (let i = 0; i < 3; i++) {
        transformerCtx.fillText('词' + (i + 1), 100, 30 + i * 50);
    }
    
    // 绘制输出序列
    for (let i = 0; i < 3; i++) {
        transformerCtx.fillText('词' + (i + 1), 400, 30 + i * 50);
    }
    
    transformerVisualization.appendChild(transformerCanvas);
}, 200);

// 为LLM创建简单的可视化
setTimeout(() => {
    const llmCanvas = document.createElement('canvas');
    llmCanvas.width = 400;
    llmCanvas.height = 200;
    llmCanvas.style.borderRadius = '12px';
    llmCanvas.style.backgroundColor = 'rgba(255, 255, 255, 0.05)';
    
    const llmCtx = llmCanvas.getContext('2d');
    
    // 绘制数据流
    llmCtx.fillStyle = '#4ade80';
    llmCtx.fillRect(50, 50, 300, 100);
    llmCtx.fillStyle = '#e0e0e0';
    llmCtx.font = '14px Inter';
    llmCtx.textAlign = 'center';
    llmCtx.fillText('LLM模型', 200, 100);
    
    // 绘制训练数据
    llmCtx.fillStyle = '#3b82f6';
    llmCtx.fillRect(50, 180, 80, 20);
    llmCtx.fillStyle = '#e0e0e0';
    llmCtx.fillText('训练数据', 90, 195);
    
    // 绘制推理
    llmCtx.fillStyle = '#f59e0b';
    llmCtx.fillRect(270, 180, 80, 20);
    llmCtx.fillStyle = '#e0e0e0';
    llmCtx.fillText('推理', 310, 195);
    
    // 绘制箭头
    llmCtx.strokeStyle = '#4ade80';
    llmCtx.lineWidth = 2;
    llmCtx.beginPath();
    llmCtx.moveTo(200, 150);
    llmCtx.lineTo(200, 180);
    llmCtx.stroke();
    
    // 绘制箭头头部
    llmCtx.beginPath();
    llmCtx.moveTo(200, 180);
    llmCtx.lineTo(195, 170);
    llmCtx.lineTo(205, 170);
    llmCtx.closePath();
    llmCtx.fill();
    
    // 绘制参数规模
    llmCtx.fillStyle = '#4ade80';
    llmCtx.font = '16px Inter';
    llmCtx.fillText('175B+ 参数', 200, 30);
    
    llmVisualization.appendChild(llmCanvas);
}, 300);